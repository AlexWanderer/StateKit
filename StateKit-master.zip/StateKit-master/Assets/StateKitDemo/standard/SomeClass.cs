using UnityEngine;
using System.Collections;


public class SomeClass
{
	public string someString = "doood";
	public int someInt = 234;
}
